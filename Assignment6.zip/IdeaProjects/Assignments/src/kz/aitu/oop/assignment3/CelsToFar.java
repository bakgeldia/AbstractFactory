package kz.aitu.oop.assignment3;

public class CelsToFar implements BaseConverter{
    public double celsius;

    public CelsToFar(){
        this.celsius = 0.0;
    }

    public CelsToFar(double celsius) {
        this.celsius=celsius;
    }

    @Override
    public double convert()
    {
        return celsius*9/5 + 32;
    }
}
