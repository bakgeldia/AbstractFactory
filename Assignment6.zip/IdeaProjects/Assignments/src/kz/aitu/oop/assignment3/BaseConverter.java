package kz.aitu.oop.assignment3;

public interface BaseConverter {
    double convert();
}
