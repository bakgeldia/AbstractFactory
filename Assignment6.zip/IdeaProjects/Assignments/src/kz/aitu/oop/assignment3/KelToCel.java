package kz.aitu.oop.assignment3;

public class KelToCel implements BaseConverter {
    public double kelvins;

    public KelToCel(){
        this.kelvins = 273.15;
    }

    public KelToCel(double kelvins) {
        this.kelvins=kelvins;
    }

    @Override
    public double convert()
    {
        return kelvins-273.15;
    }
}
