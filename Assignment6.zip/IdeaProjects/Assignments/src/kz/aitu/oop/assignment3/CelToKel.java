package kz.aitu.oop.assignment3;

public class CelToKel implements BaseConverter {
    public double celsius;

    public CelToKel(){
        this.celsius = 0.0;
    }

    public CelToKel(double celsius) {
        this.celsius=celsius;
    }

    @Override
    public double convert()
    {
        return celsius+273.15;
    }
}
