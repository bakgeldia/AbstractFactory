package kz.aitu.oop.assignment3;

public class PostgreSQL implements BaseConnect {
    @Override
    public void DBConnect() {
        System.out.println("Connected succesfully to PostgreSQL");
    }

    public void execSQL(String query){
        System.out.println("query has been executed(PostgreSQL)");
    }
}
