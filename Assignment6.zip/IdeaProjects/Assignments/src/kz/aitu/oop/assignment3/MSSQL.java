package kz.aitu.oop.assignment3;


public class MSSQL implements BaseConnect{
    @Override
    public void DBConnect(){
        System.out.println("Connected succesfully to MSSQL");
    }

    @Override
    public void execSQL(String query) {
        System.out.println("query has been executed(MSSQL)");
    }
}
