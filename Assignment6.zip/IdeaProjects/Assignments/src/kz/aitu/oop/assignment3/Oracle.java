package kz.aitu.oop.assignment3;

public class Oracle implements BaseConnect {
    @Override
    public void DBConnect(){
        System.out.println("Connected to Oracle successfully");
    }

    @Override
    public void execSQL(String query){
        System.out.println("query has been executed(Oracle)");
    }
}
