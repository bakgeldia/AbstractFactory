package kz.aitu.oop.assignment3;

public interface BaseConnect {
    void DBConnect();
    void execSQL(String query);
}
