package kz.aitu.oop.assignment3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MySQL implements BaseConnect{
    @Override
    public void DBConnect(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/converter", "root", "");

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("Select * from data");
            while(rs.next())
                System.out.println(rs.getInt(1) + " " + rs.getDouble(2) + " " + rs.getDouble(3)
                                                        + " " + rs.getDouble(4));
            con.close();
        }

        catch (Exception e) {
            System.out.println(e);
        }

        System.out.println("Connected succesfully to MySQL");
    }

    @Override
    public void execSQL(String query){
        System.out.println("Query has been executed(MySQL)");
    }

}
