package kz.aitu.oop.assignment3;

public class DemoClass {
    public static void main(String[] args) {
        BaseConnect Connect = new MySQL();
        Connect.DBConnect();
        Connect.execSQL("Select");

        BaseConnect Connect1 = new PostgreSQL();
        Connect1.DBConnect();
        Connect1.execSQL("Select");

        BaseConnect Connect2 = new Oracle();
        Connect2.DBConnect();
        Connect2.execSQL("Select");

        BaseConnect Connect3 = new MSSQL();
        Connect3.DBConnect();
        Connect3.execSQL("Select");



        System.out.println("\n");
        BaseConverter[] BConverter = {new CelsToFar(2),
                                         new CelToKel(4),
                                         new FarToCels(39),
                                         new KelToCel(300)};

        for(BaseConverter BC : BConverter)
            System.out.println(BC.convert());

        CelToKel celstokel = new CelToKel();
        BConverter[0] = celstokel;

    }
}
