package kz.aitu.oop.assignment3;

public class FarToCels implements BaseConverter {
    public double far;

    public FarToCels(){
        this.far = 32;
    }

    public FarToCels(double far)
    {
        this.far=far;
    }

    @Override
    public double convert()
    {
        return (far-32)*5/9;
    }
}
