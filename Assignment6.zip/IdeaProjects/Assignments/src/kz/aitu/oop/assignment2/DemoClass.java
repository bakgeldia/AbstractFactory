package kz.aitu.oop.assignment2;

public class DemoClass {
        public static void main(String[] args) {
            Figure[] figure = {new Rectangle(),
                    new Triangle(),
                    new Circle(),
                    new EquilateralTriangle(),
                    new Square()};

            for(Figure Fig : figure)
                System.out.println(Fig.toString() + ": area = " + Fig.findArea() + " perimeter = " + Fig.findPerimeter());
        }
}
