package kz.aitu.oop.assignment2;

public class Triangle extends Figure {
    private static String nameOfFigure = "Triangle";

    private double sideA;
    private double sideB;
    private double sideC;

    public Triangle(){
        sideA=1;
        sideB=1;
        sideC=1;
    }
    public Triangle(double sideA, double sideB, double sideC) {
        this.sideA = sideA;
        this.sideB = sideB;
        this.sideC = sideC;
    }

    @Override
    public double findArea() {
        double p = (sideA + sideB + sideC) / 2;
        double area = Math.sqrt(p * (p - sideA) * (p - sideB) * (p - sideC));
        return area;
    }

    @Override
    public double findPerimeter(){
        double P = sideA+sideB+sideC;
        return P;
    }

    @Override
    public String toString() {
        return nameOfFigure;
    }
}
