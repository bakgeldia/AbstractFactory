package kz.aitu.oop.assignment2;

public class Rectangle extends Figure {
    private static String nameOfFigure = "Rectangle";

    private double sideA;
    private double sideB;

    public Rectangle(){
        sideA = 1;
        sideB = 1;
    }

    public Rectangle(double sideA, double sideB) {
        this.sideA = sideA;
        this.sideB = sideB;
    }

    @Override
    public double findArea() {
        return sideA * sideB;
    }

    @Override
    public double findPerimeter(){
        double P = (sideA+sideB)*2;
        return P;
    }

    @Override
    public String toString() {
        return nameOfFigure;
    }
}