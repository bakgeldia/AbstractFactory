package kz.aitu.oop.assignment2;

public class EquilateralTriangle extends Triangle{
    private static String nameOfFigure = "EquilateralTriangle";

    private double sideA;
    private double sideB;
    private double sideC;

    public EquilateralTriangle() {
        sideA=1;
        sideB=1;
        sideC=1;
    }

    public EquilateralTriangle(double sideA, double sideB, double sideC) {
        this.sideA = sideA;
        this.sideB = sideB;
        this.sideC = sideC;
    }

    @Override
    public double findArea() {
        double p = (sideA + sideB + sideC) / 2;
        double area = Math.sqrt(p * (p - sideA) * (p - sideB) * (p - sideC));
        return area;
    }

    @Override
    public double findPerimeter(){
        double P = sideA+sideB+sideC;
        return P;
    }

    @Override
    public String toString() {
        return nameOfFigure;
    }
}