package kz.aitu.oop.assignment2;

public class Square extends Rectangle {
    private static String nameOfFigure = "Rectangle";

    private double sideA;
    private double sideB;

    public Square(){
        sideA=1;
        sideB=1;
    }

    public Square(double sideA, double sideB) {
        this.sideA = sideA;
        this.sideB = sideB;
    }

    @Override
    public double findArea() {
        return sideA * sideB;
    }

    @Override
    public double findPerimeter(){
        double P = (sideA+sideB)*2;
        return P;
    }

    @Override
    public String toString() {
        return nameOfFigure;
    }
}
