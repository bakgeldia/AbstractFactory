package kz.aitu.oop.assignment2;

public abstract class Figure {
    public abstract double findArea();
    public abstract double findPerimeter();
    public abstract String toString();
}
