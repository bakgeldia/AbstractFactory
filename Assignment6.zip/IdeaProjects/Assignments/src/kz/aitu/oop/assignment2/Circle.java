package kz.aitu.oop.assignment2;

public class Circle extends Figure {
    private static String nameOfFigure = "Circle";

    private double radius;

    public Circle() {
        radius = 1;
    }

    public Circle(double radius) {
        this.radius = radius;
    }

    public double findDiameter(){
        double diameter = radius*2;
        return diameter;
    }

    @Override
    public double findArea(){
        double area = Math.PI * radius * radius;
        return area;
    }

    @Override
    public double findPerimeter(){
        double C = 2 * Math.PI * radius;
        return C;
    }

    @Override
    public String toString() {
        return nameOfFigure;
    }
}
