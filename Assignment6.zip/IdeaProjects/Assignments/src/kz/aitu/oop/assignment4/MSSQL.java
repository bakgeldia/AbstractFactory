package kz.aitu.oop.assignment4;

import java.sql.Connection;

public class MSSQL implements BaseConnect{
    @Override
    public Connection connect(String url, String user, String password){
        System.out.println("Connected succesfully to MSSQL");
        return null;
    }

    @Override
    public void execSQL(String sql, String[] params) {
        System.out.println("query has been executed(MSSQL)");
    }
}
