package kz.aitu.oop.assignment4;

import java.sql.Connection;

public class Oracle implements BaseConnect{
    @Override
    public Connection connect(String url, String user, String password){
        System.out.println("Connected to Oracle successfully");
        return null;
    }

    @Override
    public void execSQL(String sql, String[] params){
        System.out.println("query has been executed(Oracle)");
    }
}
