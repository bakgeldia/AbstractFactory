package kz.aitu.oop.assignment4;
import java.sql.*;

public class MySQL implements BaseConnect {
    private Connection con;
    @Override
    public Connection connect(String url, String user, String password){
        try{
            //Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url, user, password);
        }

        catch (Exception e) {
            System.out.println(e);
        }
        System.out.println("Connected succesfully to MySQL");
        return null;
    }

    @Override
    public void execSQL(String sql, String[] params){
        try{
                PreparedStatement stmt=con.prepareStatement(sql);
                int i=stmt.executeUpdate();
                System.out.println(i+" record(s) inserted/deleted/updated"); //INSERT-DELETE-UPDATE

            /*PreparedStatement stmt=con.prepareStatement(sql);
            int i=stmt.executeUpdate();
            System.out.println(i+" record(s) updated"); //UPDATE(modify)

            /*PreparedStatement stmt=con.prepareStatement(sql);
            int i=stmt.executeUpdate();
            System.out.println(i+" record(s) deleted"); */ //DELETE */

            /*PreparedStatement stmt=con.prepareStatement(sql);
            stmt.setString(1,params[0]);
            ResultSet rs=stmt.executeQuery();
            while(rs.next()){
                System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3)
                        + " " + rs.getString(4));
            } */ //Select + condition(s)

            con.close();

        } catch(Exception e){
            System.out.println(e);
        }
    }

}
