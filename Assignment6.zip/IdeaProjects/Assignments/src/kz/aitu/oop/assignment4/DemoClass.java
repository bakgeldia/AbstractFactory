package kz.aitu.oop.assignment4;

public class DemoClass {
    public static void main(String[] args) {
        BaseConnect Connect = new MySQL();
        Connect.connect("jdbc:mysql://localhost:3306/converter", "root", "");
        Connect.execSQL("select * from players)", new String[] {"Oleksandr","NAVI", "dsahds"});
    }
}

    //INSERT INTO players VALUES()
    //Update players club = Faze WHERE firstname = Egor;
    //Delete from players WHERE id = 4
