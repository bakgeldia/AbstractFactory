package kz.aitu.oop.assignment4;

import java.sql.Connection;

public class PostgreSQL implements BaseConnect{
    @Override
    public Connection connect(String url, String user, String password) {
        System.out.println("Connected succesfully to PostgreSQL");
        return null;
    }

    public void execSQL(String sql, String[] params){
        System.out.println("query has been executed(PostgreSQL)");
    }
}
