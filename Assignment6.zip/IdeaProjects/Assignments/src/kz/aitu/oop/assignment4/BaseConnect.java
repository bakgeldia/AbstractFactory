package kz.aitu.oop.assignment4;

import java.sql.Connection;

public interface BaseConnect {
    Connection connect(String url, String user, String password);
    void execSQL(String sql, String[] params);
}
