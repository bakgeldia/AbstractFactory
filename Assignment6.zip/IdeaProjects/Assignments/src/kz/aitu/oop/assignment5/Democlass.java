package kz.aitu.oop.assignment5;

public class Democlass {
    public static void main(String[] args) {
        Array<String> generic = new Array<>();
        generic.addElement("asdsad");
        generic.addElement("sadsadsa");
        generic.printElements();

        Array<Number> generic1 = new Array<>();
        generic1.addElement(12);
        generic1.addElement(3);
        generic1.addElement(5);
        generic1.addElement(4.5);


        ForStrings string = (r, t) -> r + t;
        System.out.println(string.returnString("text1","text2"));

        string = (a,b) -> b;
        System.out.println(string.returnString("dsad","fgggjgg"));
    }
}
