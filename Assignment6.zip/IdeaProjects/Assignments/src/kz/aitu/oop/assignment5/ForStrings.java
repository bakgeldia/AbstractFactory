package kz.aitu.oop.assignment5;
@FunctionalInterface
public interface ForStrings {
   String returnString(String str1, String str2);
}
