package kz.aitu.oop.assignment5;
import java.util.ArrayList;
import java.util.List;

public class Array<T>{
        private final List<T> numList = new ArrayList<>();

        public void addElement(T element) {
            numList.add(element);
        }

        public void printElements(){
            int i=0;
            for(T element: numList) {
                System.out.println(i + ": " + element);
                i++;
            }
        }
}
