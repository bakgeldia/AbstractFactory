package kz.aitu.oop.assignment6;

public interface iSofa {
    public void hasLegs();
    public void sitOn();
}
